# borderData

Save all border wait data.
